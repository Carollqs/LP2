﻿namespace PClasses
{
    partial class FrmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnParametros = new System.Windows.Forms.Button();
            this.btnInstanciaMen = new System.Windows.Forms.Button();
            this.lblDtEntra = new System.Windows.Forms.Label();
            this.lblSalMensal = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalMen = new System.Windows.Forms.TextBox();
            this.txtDtEntra = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnParametros
            // 
            this.btnParametros.Location = new System.Drawing.Point(478, 331);
            this.btnParametros.Name = "btnParametros";
            this.btnParametros.Size = new System.Drawing.Size(203, 105);
            this.btnParametros.TabIndex = 19;
            this.btnParametros.Text = "Instanciar Mensalista passando  Parametros ";
            this.btnParametros.UseVisualStyleBackColor = true;
            // 
            // btnInstanciaMen
            // 
            this.btnInstanciaMen.Location = new System.Drawing.Point(227, 331);
            this.btnInstanciaMen.Name = "btnInstanciaMen";
            this.btnInstanciaMen.Size = new System.Drawing.Size(193, 91);
            this.btnInstanciaMen.TabIndex = 18;
            this.btnInstanciaMen.Text = "Instancia Mensalista ";
            this.btnInstanciaMen.UseVisualStyleBackColor = true;
            // 
            // lblDtEntra
            // 
            this.lblDtEntra.AutoSize = true;
            this.lblDtEntra.Location = new System.Drawing.Point(120, 183);
            this.lblDtEntra.Name = "lblDtEntra";
            this.lblDtEntra.Size = new System.Drawing.Size(199, 20);
            this.lblDtEntra.TabIndex = 17;
            this.lblDtEntra.Text = "Data Entrada na Empresa ";
            // 
            // lblSalMensal
            // 
            this.lblSalMensal.AutoSize = true;
            this.lblSalMensal.Location = new System.Drawing.Point(170, 132);
            this.lblSalMensal.Name = "lblSalMensal";
            this.lblSalMensal.Size = new System.Drawing.Size(113, 20);
            this.lblSalMensal.TabIndex = 16;
            this.lblSalMensal.Text = "Salário Mensal";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(170, 75);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(51, 20);
            this.lblNome.TabIndex = 15;
            this.lblNome.Text = "Nome";
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(170, 14);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(73, 20);
            this.lblMatricula.TabIndex = 14;
            this.lblMatricula.Text = "Matrícula";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(333, 14);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 26);
            this.txtMatricula.TabIndex = 13;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(333, 69);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 26);
            this.txtNome.TabIndex = 12;
            // 
            // txtSalMen
            // 
            this.txtSalMen.Location = new System.Drawing.Point(333, 126);
            this.txtSalMen.Name = "txtSalMen";
            this.txtSalMen.Size = new System.Drawing.Size(100, 26);
            this.txtSalMen.TabIndex = 11;
            // 
            // txtDtEntra
            // 
            this.txtDtEntra.Location = new System.Drawing.Point(333, 177);
            this.txtDtEntra.Name = "txtDtEntra";
            this.txtDtEntra.Size = new System.Drawing.Size(100, 26);
            this.txtDtEntra.TabIndex = 10;
            // 
            // FrmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnParametros);
            this.Controls.Add(this.btnInstanciaMen);
            this.Controls.Add(this.lblDtEntra);
            this.Controls.Add(this.lblSalMensal);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtSalMen);
            this.Controls.Add(this.txtDtEntra);
            this.Name = "FrmHorista";
            this.Text = "FrmHorista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnParametros;
        private System.Windows.Forms.Button btnInstanciaMen;
        private System.Windows.Forms.Label lblDtEntra;
        private System.Windows.Forms.Label lblSalMensal;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalMen;
        private System.Windows.Forms.TextBox txtDtEntra;
    }
}