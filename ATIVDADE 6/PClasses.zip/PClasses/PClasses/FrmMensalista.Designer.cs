﻿namespace PClasses
{
    partial class FrmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDtEntra = new System.Windows.Forms.TextBox();
            this.txtSalMen = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalMensal = new System.Windows.Forms.Label();
            this.lblDtEntra = new System.Windows.Forms.Label();
            this.btnInstanciaMen = new System.Windows.Forms.Button();
            this.btnParametros = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtDtEntra
            // 
            this.txtDtEntra.Location = new System.Drawing.Point(225, 220);
            this.txtDtEntra.Name = "txtDtEntra";
            this.txtDtEntra.Size = new System.Drawing.Size(100, 26);
            this.txtDtEntra.TabIndex = 0;
            this.txtDtEntra.TextChanged += new System.EventHandler(this.txtDtEntra_TextChanged);
            // 
            // txtSalMen
            // 
            this.txtSalMen.Location = new System.Drawing.Point(225, 169);
            this.txtSalMen.Name = "txtSalMen";
            this.txtSalMen.Size = new System.Drawing.Size(100, 26);
            this.txtSalMen.TabIndex = 1;
            this.txtSalMen.TextChanged += new System.EventHandler(this.txtSalMen_TextChanged);
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(225, 112);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 26);
            this.txtNome.TabIndex = 2;
            this.txtNome.TextChanged += new System.EventHandler(this.txtNome_TextChanged);
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(225, 57);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 26);
            this.txtMatricula.TabIndex = 3;
            this.txtMatricula.TextChanged += new System.EventHandler(this.txtMatricula_TextChanged);
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(62, 57);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(73, 20);
            this.lblMatricula.TabIndex = 4;
            this.lblMatricula.Text = "Matrícula";
            this.lblMatricula.Click += new System.EventHandler(this.lblMatricula_Click);
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(62, 118);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(51, 20);
            this.lblNome.TabIndex = 5;
            this.lblNome.Text = "Nome";
            this.lblNome.Click += new System.EventHandler(this.lblNome_Click);
            // 
            // lblSalMensal
            // 
            this.lblSalMensal.AutoSize = true;
            this.lblSalMensal.Location = new System.Drawing.Point(62, 175);
            this.lblSalMensal.Name = "lblSalMensal";
            this.lblSalMensal.Size = new System.Drawing.Size(113, 20);
            this.lblSalMensal.TabIndex = 6;
            this.lblSalMensal.Text = "Salário Mensal";
            this.lblSalMensal.Click += new System.EventHandler(this.lblSalMensal_Click);
            // 
            // lblDtEntra
            // 
            this.lblDtEntra.AutoSize = true;
            this.lblDtEntra.Location = new System.Drawing.Point(12, 226);
            this.lblDtEntra.Name = "lblDtEntra";
            this.lblDtEntra.Size = new System.Drawing.Size(199, 20);
            this.lblDtEntra.TabIndex = 7;
            this.lblDtEntra.Text = "Data Entrada na Empresa ";
            this.lblDtEntra.Click += new System.EventHandler(this.lblDtEntra_Click);
            // 
            // btnInstanciaMen
            // 
            this.btnInstanciaMen.Location = new System.Drawing.Point(119, 374);
            this.btnInstanciaMen.Name = "btnInstanciaMen";
            this.btnInstanciaMen.Size = new System.Drawing.Size(193, 91);
            this.btnInstanciaMen.TabIndex = 8;
            this.btnInstanciaMen.Text = "Instancia Mensalista ";
            this.btnInstanciaMen.UseVisualStyleBackColor = true;
            this.btnInstanciaMen.Click += new System.EventHandler(this.btnInstanciaMen_Click);
            // 
            // btnParametros
            // 
            this.btnParametros.Location = new System.Drawing.Point(370, 374);
            this.btnParametros.Name = "btnParametros";
            this.btnParametros.Size = new System.Drawing.Size(203, 105);
            this.btnParametros.TabIndex = 9;
            this.btnParametros.Text = "Instanciar Mensalista passando  Parametros ";
            this.btnParametros.UseVisualStyleBackColor = true;
            this.btnParametros.Click += new System.EventHandler(this.btnParametros_Click);
            // 
            // FrmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(965, 509);
            this.Controls.Add(this.btnParametros);
            this.Controls.Add(this.btnInstanciaMen);
            this.Controls.Add(this.lblDtEntra);
            this.Controls.Add(this.lblSalMensal);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtSalMen);
            this.Controls.Add(this.txtDtEntra);
            this.Name = "FrmMensalista";
            this.Text = "FrmMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtDtEntra;
        private System.Windows.Forms.TextBox txtSalMen;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalMensal;
        private System.Windows.Forms.Label lblDtEntra;
        private System.Windows.Forms.Button btnInstanciaMen;
        private System.Windows.Forms.Button btnParametros;
    }
}