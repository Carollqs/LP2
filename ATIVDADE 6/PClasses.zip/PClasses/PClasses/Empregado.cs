﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace PClasses
{
    abstract internal class Empregado
    {
        /*class tem atributos e metodos*/
        private int matricula; //atributo
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;
        //internal  - todo o projeto 
        //public dentro e fora da class e outros projetos 
        //protected class filhas tbm veem 
        // protect interno class, derivadas e derivadas em outro projeto 
        //private ninguem fora da class enxerga, nem a subclass, nem o obj

        public int Matricula // propriedade
        {
            get { return matricula; }
            set { matricula = value; }

        }



        public string NomeEmpregado
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; } // set é atibuição, a entrada
        }

        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }


        public virtual int TempoTrabalho()
        {
            //representa um intervalo de tempo
            TimeSpan span =
                DateTime.Today.Subtract(DataEntradaEmpresa); // qnts dias trabalhados, compara a data de entrada com o dia de hj
            return (span.Days);




        }

        // classs abtrata nao permite criar objetos dela
        public abstract double SalarioBruto();
    }


}
