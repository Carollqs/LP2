﻿namespace PClasses
{
    partial class FrmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInstanciaHor = new System.Windows.Forms.Button();
            this.lblDtEntra = new System.Windows.Forms.Label();
            this.lblSalHor = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalHor = new System.Windows.Forms.TextBox();
            this.txtDtEntra = new System.Windows.Forms.TextBox();
            this.lblNumeroHoras = new System.Windows.Forms.Label();
            this.txtHoras = new System.Windows.Forms.TextBox();
            this.txtFaltas = new System.Windows.Forms.TextBox();
            this.lblFaltas = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnInstanciaHor
            // 
            this.btnInstanciaHor.Location = new System.Drawing.Point(301, 315);
            this.btnInstanciaHor.Name = "btnInstanciaHor";
            this.btnInstanciaHor.Size = new System.Drawing.Size(193, 91);
            this.btnInstanciaHor.TabIndex = 18;
            this.btnInstanciaHor.Text = "Instancia Horista";
            this.btnInstanciaHor.UseVisualStyleBackColor = true;
            this.btnInstanciaHor.Click += new System.EventHandler(this.btnInstanciaHor_Click);
            // 
            // lblDtEntra
            // 
            this.lblDtEntra.AutoSize = true;
            this.lblDtEntra.Location = new System.Drawing.Point(110, 217);
            this.lblDtEntra.Name = "lblDtEntra";
            this.lblDtEntra.Size = new System.Drawing.Size(199, 20);
            this.lblDtEntra.TabIndex = 17;
            this.lblDtEntra.Text = "Data Entrada na Empresa ";
            // 
            // lblSalHor
            // 
            this.lblSalHor.AutoSize = true;
            this.lblSalHor.Location = new System.Drawing.Point(170, 132);
            this.lblSalHor.Name = "lblSalHor";
            this.lblSalHor.Size = new System.Drawing.Size(128, 20);
            this.lblSalHor.TabIndex = 16;
            this.lblSalHor.Text = "Salário  por Hora";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(170, 75);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(51, 20);
            this.lblNome.TabIndex = 15;
            this.lblNome.Text = "Nome";
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(170, 14);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(73, 20);
            this.lblMatricula.TabIndex = 14;
            this.lblMatricula.Text = "Matrícula";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(333, 14);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 26);
            this.txtMatricula.TabIndex = 13;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(333, 69);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 26);
            this.txtNome.TabIndex = 12;
            // 
            // txtSalHor
            // 
            this.txtSalHor.Location = new System.Drawing.Point(333, 126);
            this.txtSalHor.Name = "txtSalHor";
            this.txtSalHor.Size = new System.Drawing.Size(100, 26);
            this.txtSalHor.TabIndex = 11;
            // 
            // txtDtEntra
            // 
            this.txtDtEntra.Location = new System.Drawing.Point(333, 217);
            this.txtDtEntra.Name = "txtDtEntra";
            this.txtDtEntra.Size = new System.Drawing.Size(100, 26);
            this.txtDtEntra.TabIndex = 10;
            // 
            // lblNumeroHoras
            // 
            this.lblNumeroHoras.AutoSize = true;
            this.lblNumeroHoras.Location = new System.Drawing.Point(160, 174);
            this.lblNumeroHoras.Name = "lblNumeroHoras";
            this.lblNumeroHoras.Size = new System.Drawing.Size(138, 20);
            this.lblNumeroHoras.TabIndex = 19;
            this.lblNumeroHoras.Text = "Numero de  Horas";
            // 
            // txtHoras
            // 
            this.txtHoras.Location = new System.Drawing.Point(333, 171);
            this.txtHoras.Name = "txtHoras";
            this.txtHoras.Size = new System.Drawing.Size(100, 26);
            this.txtHoras.TabIndex = 20;
            // 
            // txtFaltas
            // 
            this.txtFaltas.Location = new System.Drawing.Point(333, 266);
            this.txtFaltas.Name = "txtFaltas";
            this.txtFaltas.Size = new System.Drawing.Size(100, 26);
            this.txtFaltas.TabIndex = 21;
            this.txtFaltas.TextChanged += new System.EventHandler(this.txtFaltas_TextChanged);
            // 
            // lblFaltas
            // 
            this.lblFaltas.AutoSize = true;
            this.lblFaltas.Location = new System.Drawing.Point(144, 266);
            this.lblFaltas.Name = "lblFaltas";
            this.lblFaltas.Size = new System.Drawing.Size(111, 20);
            this.lblFaltas.TabIndex = 22;
            this.lblFaltas.Text = "Dias de Faltas";
            // 
            // FrmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblFaltas);
            this.Controls.Add(this.txtFaltas);
            this.Controls.Add(this.txtHoras);
            this.Controls.Add(this.lblNumeroHoras);
            this.Controls.Add(this.btnInstanciaHor);
            this.Controls.Add(this.lblDtEntra);
            this.Controls.Add(this.lblSalHor);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtSalHor);
            this.Controls.Add(this.txtDtEntra);
            this.Name = "FrmHorista";
            this.Text = "FrmHorista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnInstanciaHor;
        private System.Windows.Forms.Label lblDtEntra;
        private System.Windows.Forms.Label lblSalHor;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalHor;
        private System.Windows.Forms.TextBox txtDtEntra;
        private System.Windows.Forms.Label lblNumeroHoras;
        private System.Windows.Forms.TextBox txtHoras;
        private System.Windows.Forms.TextBox txtFaltas;
        private System.Windows.Forms.Label lblFaltas;
    }
}