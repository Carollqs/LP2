﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    public partial class FrmMensalista : Form
    {
        public FrmMensalista()
        {
            InitializeComponent();
        }

        private void btnInstanciaMen_Click(object sender, EventArgs e)
        {

            Mensalista objMensalista = new Mensalista();
             objMensalista.NomeEmpregado = txtNome.Text;
            objMensalista.Matricula = Convert.ToInt32(txtMatricula.Text); 
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtDtEntra.Text);
            objMensalista.SalarioMensal =   Convert.ToDouble(txtSalMen.Text);


            MessageBox.Show(" Nome = " + objMensalista.NomeEmpregado + "\n" +
                 "Matricula = " + objMensalista.Matricula + "\n" +
                 "Tempo Trabalho: " + objMensalista.TempoTrabalho() + "\n" +
                 "Salario Final = " + objMensalista.SalarioBruto().ToString("N2"));

            // propriedade 
            // metodo tem() no final 

            MessageBox.Show(Mensalista.Empresa);
            MessageBox.Show(Mensalista.Filial);

            //polimorfismo um mesmo metodo/ nome 

        }

        private void txtSalMen_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMatricula_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblMatricula_Click(object sender, EventArgs e)
        {

        }

        private void lblNome_Click(object sender, EventArgs e)
        {

        }

        private void lblSalMensal_Click(object sender, EventArgs e)
        {

        }

        private void lblDtEntra_Click(object sender, EventArgs e)
        {

        }

        private void txtDtEntra_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnParametros_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista(
                Convert.ToInt32(txtMatricula.Text),
                txtNome.Text,
                Convert.ToDateTime(txtDtEntra.Text),
                Convert.ToDouble(txtSalMen.Text));

            MessageBox.Show(" Nome = " + objMensalista.NomeEmpregado + "\n" +
                 "Matricula = " + objMensalista.Matricula + "\n" +
                 "Tempo Trabalho: " + objMensalista.TempoTrabalho() + "\n" +
                 "Salario Final = " + objMensalista.SalarioBruto().ToString("N2"));

        }
    }
}
